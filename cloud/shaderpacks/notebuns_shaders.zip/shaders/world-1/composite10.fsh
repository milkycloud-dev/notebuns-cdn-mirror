#version 120
#define DIMENSION_NETHER

#include "/program/composite10.fsh"
