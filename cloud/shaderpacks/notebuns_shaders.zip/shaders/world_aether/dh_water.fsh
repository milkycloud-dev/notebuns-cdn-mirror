#version 120
#define DIMENSION_OVERWORLD
#define DIMENSION_AETHER

#include "/program/dh_water.fsh"
