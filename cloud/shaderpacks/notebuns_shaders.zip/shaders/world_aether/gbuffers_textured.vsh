#version 120
#define DIMENSION_OVERWORLD
#define DIMENSION_AETHER

#define GBUFFERS_TEXTURED
#include "/program/gbuffers_basic.vsh"
