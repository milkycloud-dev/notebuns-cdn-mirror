#version 120
#define DIMENSION_OVERWORLD
#define DIMENSION_AETHER

#include "/program/gbuffers_weather.vsh"
