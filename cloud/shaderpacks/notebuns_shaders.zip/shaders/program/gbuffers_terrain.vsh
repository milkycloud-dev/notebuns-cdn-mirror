#include "/lib/all_the_libs.glsl"

#include "/global/lighting.vsh"

void main() {
    init_generic();

    #ifdef WAVY_PLANTS
    if (ViewPos.z > -96) {
        vec3 WorldPos = to_player_pos(ViewPos);
        WorldPos += cameraPosition;
        vec3 WavePos = WorldPos / WAVE_SIZE + frameTimeCounter * WAVE_SPEED;
        WavePos = sin(WavePos);
        float Noise = WavePos.x * WavePos.y * WavePos.z;
        Noise *= WAVE_AMPLITUDE + rainStrength * 0.04;
        #ifdef WAVE_LEAVES
        if (material == 10003) {
            WorldPos.xz += Noise * 0.35;
        }
        else
        #endif
        if (material == 10004) {
            if (gl_MultiTexCoord0.t < mc_midTexCoord.t)
                WorldPos.xz += Noise * 0.55;
        }
        else if (material == 10005) {
            if (gl_MultiTexCoord0.t < mc_midTexCoord.t)
                WorldPos.xz += Noise * 0.55 * 0.5;
        }
        else if (material == 10006) {
            if (gl_MultiTexCoord0.t > mc_midTexCoord.t)
                WorldPos.xz += Noise * 0.55 * 0.5;
            else
                WorldPos.xz += Noise * 0.55;
        }

        WorldPos -= cameraPosition;
        WorldPos = mat3(gbufferModelView) * WorldPos;
        gl_Position = gl_ProjectionMatrix * vec4(WorldPos, 1);
    }
    #endif

    #if TAA_MODE >= 2
    gl_Position.xy += taaJitter * gl_Position.w;
    #endif
}