#include "/lib/all_the_libs.glsl"
#include "/global/lighting.vsh"

void main() {
	
	init_generic();
	vec3 ViewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;
	vec3 WorldPos = mat3(gbufferModelViewInverse) * ViewPos;
	WorldPos += cameraPosition;

	// Раньше время множилось на высоту: частота волны росла весь сеанс. Теперь волна
	// плавно качается во времени, а её частота по высоте постоянная.
	WorldPos.xz += sin(WorldPos.y / WAVE_SIZE * 0.35 + frameTimeCounter * WAVE_SPEED * 0.3) * RAIN_TILT_STRENGTH * 0.15;
	
	WorldPos -= cameraPosition;
	WorldPos = mat3(gbufferModelView) * WorldPos;
	gl_Position = gl_ProjectionMatrix * vec4(WorldPos, 1);
}

