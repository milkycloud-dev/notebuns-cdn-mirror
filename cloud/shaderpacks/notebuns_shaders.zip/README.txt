notebuns_shaders
================
Author: eturnercus
Based on DreamLight / Mellow (TheCMK)

Iris: Video Settings -> Shader Packs -> notebuns_shaders
Profile MEDIUM recommended.

Default color scheme: Choc v7 (COLOR_SCHEME 3).
Gentle plant waving, fancy lava, denser Nether fog.
Main screen has: Sun Rays (Godrays) toggle + settings.
2026-09-23 (NoteBuns): в Aether нет солнца, луны, звёзд и лучей (как и без шейдеров), свет сверху — ничего не прыгает при сбросе времени.
